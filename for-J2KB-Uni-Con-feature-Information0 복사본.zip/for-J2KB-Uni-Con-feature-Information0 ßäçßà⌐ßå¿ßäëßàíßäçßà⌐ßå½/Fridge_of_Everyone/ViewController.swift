//
//  ViewController.swift
//  Fridge_of_Everyone
//
//  Created by simyo on 2021/05/08.
//

import UIKit
import Alamofire

class ViewController: UIViewController {
    @IBOutlet weak var label: UILabel!
    
    let mainVC : UIStoryboard = UIStoryboard(name: "Main", bundle: nil)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        // Do any additional setup after loading the view.
        
        AF.request("http://27.35.18.238/api").responseString { (res) in
            print(res.value ?? "")
            self.label.text = res.value ?? ""
            
            AF.request("http://27.35.18.238/api/login", method: .post)
        }
    }
    
}

