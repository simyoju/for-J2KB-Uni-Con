//
//  IngredientInfoViewController.swift
//  Fridge_of_Everyone
//
//  Created by simyo on 2021/05/31.
//

import UIKit

class IngredientInfoViewController: UIViewController, UITextFieldDelegate, UIPickerViewDelegate, UIPickerViewDataSource {
    
    @IBOutlet weak var showStoragePicker: UITextField!
    @IBOutlet weak var showCategoryPicker: UITextField!
    
    let storages = ["냉장", "냉동", "실온"]
    let categories = ["전체", "고기", "생선", "야채", "과일", "베이커리", "기타"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        showStoragePicker.tintColor = .clear
        createPickerView()
        dismissPickerView()

        // Do any additional setup after loading the view.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        // PickerView 안에 몇 개의 선택 가능한 리스트를 표현할 것인지?
        // ex. 생년월일 같은 경우, 연도 - 1개, 월 - 1개, 일 - 1개 총 3개
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        // PickerView에 표시될 항목에 개수를 반환
        return storages.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        // PickerView 내에서 특정한 위치(row)를 가리키게 될 때, 그 위치에 해당하는 문자열을 반환하는 메서드
        return storages[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        // PickerView에서 특정 row가 focus 되었을 때 어떤 행동을 할지 정의하는 메서드
        showStoragePicker.text = storages[row]
    }
    
    func createPickerView() {
        let pickerView = UIPickerView()
        pickerView.delegate = self
        showStoragePicker.inputView = pickerView
    }
    
    func dismissPickerView(){
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        let btn = UIBarButtonItem()
        btn.title = "선택"
        btn.target = self
        btn.action = #selector(pickerExit)
        toolBar.setItems([btn], animated: true)
        toolBar.isUserInteractionEnabled = true
        showStoragePicker.inputAccessoryView = toolBar
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @objc func pickerExit(){
        self.view.endEditing(true)
    }
}
