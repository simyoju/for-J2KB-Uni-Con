//
//  JoinViewController.swift
//  Fridge_of_Everyone
//
//  Created by simyo on 2021/05/31.
//

import UIKit
import Alamofire
import SwiftyJSON

class JoinViewController: UIViewController {
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var pwTextField: UITextField!
    @IBOutlet weak var nickTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func finishBtnClicked(_ sender: Any) {
        var email = emailTextField.text ?? ""
        var pw = pwTextField.text ?? ""
        var nickName = nickTextField.text ?? ""
        
        if email.count == 0 || pw.count == 0 || nickName.count == 0 {
            var alert = UIAlertController(title: "다시 입력해주세요", message: "빈 칸이 있습니다", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "확인", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return
        }
            
        var parameters = [
            "email" : email,
            "password" : pw,
            "nickname" : nickName
        ]
        
        /* 안 써도 잘되네
        let header: HTTPHeaders = [
            "Content-Type": "application/json"
        ]*/
            
        AF.request("http://27.35.18.238/api/users", method: .post, parameters: parameters, encoding: JSONEncoding.default).responseJSON { (response) in
            debugPrint(response)
            if var value = response.value {
                var json = JSON(value)
            }
        }
            
    }
}

    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


